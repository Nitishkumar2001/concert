export interface Ticket {


    bookid: number;
    seatnum: number;
    concertId: number;
    userId: number;
    date: Date;
}