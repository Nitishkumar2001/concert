import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConcertIndexComponent } from './concert-index.component';

describe('ConcertIndexComponent', () => {
  let component: ConcertIndexComponent;
  let fixture: ComponentFixture<ConcertIndexComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ConcertIndexComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ConcertIndexComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
