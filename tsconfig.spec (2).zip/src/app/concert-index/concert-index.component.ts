import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import {Data} from '../data';

@Component({
  selector: 'app-concert-index',
  templateUrl: './concert-index.component.html',
  styleUrls: ['./concert-index.component.css']
})
export class ConcertIndexComponent implements OnInit  {
  datas: Data[]=[];
  constructor(
    public dataService :DataService
  ) { }

  ngOnInit(): void {
    this.dataService.getAll().subscribe((data: Data[])=>{
      this.datas = data;
      console.log(this.datas);
    })  
  }

  deletePost(id:number){
    this.dataService.delete(id).subscribe(res => {
         this.datas = this.datas.filter(item => item.concertId !== id);
         console.log('Post deleted successfully!');
    })
  }
}
