import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../user';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
})
export class NavbarComponent implements OnInit {
  IsLoggedIn: boolean = false;
  IsAdmin: boolean = false;
  IsCustomer:boolean=false
  users: User[] = [];
  decodedToken:{[key:string]:string;} |undefined;
  id?:any;
  userType: any = localStorage.getItem("role");
  constructor(public userService: UserService) {}

  ngOnInit(): void {
    
    if(localStorage.getItem('app_token') !=null){
      this.IsLoggedIn=true;
    }
    console.log(this.IsLoggedIn);
    var x = localStorage.getItem('app_token');
    this.id=localStorage.getItem('userId');
    if(x){
      
      this.IsAdmin=JSON.parse(x).value.username=='Admin';
      // this.id=JSON.parse(x).userId;
      // console.log(this.id)
      this.IsCustomer = JSON.parse(x).value.username=='Customer';
      
      
     }

     console.log(this.id);
     this.userService.getAll().subscribe((data: User[])=>{
      this.users = data;
      console.log(this.users);
    })  
  
  }

 
  //  this.load();

  Logout() {
    localStorage.removeItem('app_token');
    location.href = '/login';
    this.IsLoggedIn=false;
    console.log(this.IsLoggedIn);
   
  }
}
