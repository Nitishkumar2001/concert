import { Component ,OnInit} from '@angular/core';
import { DataService } from '../data.service';
import { Data } from '../data';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-view-concert',
  templateUrl: './view-concert.component.html',
  styleUrls: ['./view-concert.component.css']
})
export class ViewConcertComponent implements OnInit{
  FindTickets:any;
data!:Data;
searchForm;
  constructor(private dataService: DataService,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router
    ) { 
      this.searchForm = this.formBuilder.group({
        search: '',
      });
    }

  ngOnInit(): void {
    this.dataService.sendGetRequest().subscribe((data: any)=>{
      console.log(data);
      this.FindTickets = data;
    })
  }

}
