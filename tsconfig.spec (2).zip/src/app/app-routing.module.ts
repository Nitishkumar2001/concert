import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ConcertCreateComponent } from './concert-create/concert-create.component';
import { IndexComponent } from './index/index.component';
import { LoginComponent } from './login/login.component';
import { signupComponent } from './signup/signup.component';
import { CustomerDashboardComponent } from './customer-dashboard/customer-dashboard.component';
import { ViewConcertComponent } from './view-concert/view-concert.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { ViewProfileComponent } from './view-profile/view-profile.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { BookTicketComponent } from './book-ticket/book-ticket.component';
import { UserBookingsComponent } from './user-bookings/user-bookings.component';
import { ConcertIndexComponent } from './concert-index/concert-index.component';
import { AllBookingsComponent } from './all-bookings/all-bookings.component';
import { ContactusComponent } from './contactus/contactus.component';
import { ConcertViewComponent } from './concert-view/concert-view.component';
import { AboutusComponent } from './aboutus/aboutus.component';

const routes: Routes = [ { 
  path: '', component: IndexComponent },
{ path: "login", component: LoginComponent },
{ path: "signup", component: signupComponent },
{path:"customerDashboard",component:CustomerDashboardComponent},
{path:"adminDashboard",component:AdminDashboardComponent},
{path:"viewConcert",component:ViewConcertComponent},
{path:"viewProfile/:userid",component:ViewProfileComponent},
{path:"editProfile/:userid",component:EditProfileComponent},
{path:"bookTicket",component:BookTicketComponent},
{path:"userBookings",component:UserBookingsComponent},
{path:"concertIndex",component:ConcertIndexComponent},
{path:"concertCreate",component:ConcertCreateComponent},
{path:"allBookings",component:AllBookingsComponent},
{path:"contactus",component:ContactusComponent},
{path:"aboutus",component:AboutusComponent},
{path:"concertView/:concertId/view",component:ConcertViewComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
