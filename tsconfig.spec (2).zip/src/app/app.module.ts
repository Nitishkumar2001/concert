import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AllBookingsComponent } from './all-bookings/all-bookings.component';
import { BookTicketComponent } from './book-ticket/book-ticket.component';
import { ContactusComponent } from './contactus/contactus.component';
import { CustomerDashboardComponent } from './customer-dashboard/customer-dashboard.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { IndexComponent } from './index/index.component';
import { LoginComponent } from './login/login.component';
import { ConcertIndexComponent } from './concert-index/concert-index.component';
import { ConcertViewComponent } from './concert-view/concert-view.component';
import { ConcertCreateComponent } from './concert-create/concert-create.component';
import { NavbarComponent } from './navbar/navbar.component';
import { signupComponent } from './signup/signup.component';
import { UserBookingsComponent } from './user-bookings/user-bookings.component';
import { ViewConcertComponent } from './view-concert/view-concert.component';
import { ViewProfileComponent } from './view-profile/view-profile.component';
import { SearchFilterPipe } from './search-filter.pipe';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent,
    AboutusComponent,
    AdminDashboardComponent,
    AllBookingsComponent,
    BookTicketComponent,
    ContactusComponent,
    CustomerDashboardComponent,
    EditProfileComponent,
    IndexComponent,
    LoginComponent,
    ConcertIndexComponent,
    ConcertViewComponent,
    ConcertCreateComponent,
    NavbarComponent,
    signupComponent,
    UserBookingsComponent,
    ViewConcertComponent,
    ViewProfileComponent,
    SearchFilterPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule,ReactiveFormsModule, BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
