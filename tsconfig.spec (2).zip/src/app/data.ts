export interface Data {
  
    concertId: number;
    location: string;
    theatrename: string;
    concertname:string;
    concertLink:string;
    slot:string;
    charges:number;
    date:Date;
}

