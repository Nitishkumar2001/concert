import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { DataService } from '../data.service';
import {Data} from '../data';

@Component({
  selector: 'app-concert-create',
  templateUrl: './concert-create.component.html',
  styleUrls: ['./concert-create.component.css']
})
export class ConcertCreateComponent implements OnInit {
  form!: FormGroup;
  data!:Data;
  constructor(
    public dataService: DataService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      location: new FormControl('', Validators.required),
      theatrename: new FormControl('', Validators.required),
      concertname:new FormControl('', Validators.required),
      concertLink: new FormControl('', Validators.required),
      slot: new FormControl('', Validators.required),
      charges:new FormControl('', Validators.required),
     date: new FormControl('', Validators.required),
    });
  }
  get f(){
    return this.form.controls;
  }
  
  submit(){
    console.log(this.form.value);
   
    this.dataService.create(this.form.value).subscribe((res:any) => {
      alert("Concert details are added");
      console.log('Post created successfully!');
      //this.form.reset();
       this.router.navigateByUrl('/concertIndex');
  })
  }
}
