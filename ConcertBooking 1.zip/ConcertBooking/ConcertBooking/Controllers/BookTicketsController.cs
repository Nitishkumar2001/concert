﻿using ConcertBooking.Model;
using ConcertBooking.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ConcertBooking.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookTicketsController : ControllerBase
    {
        
        private readonly IBookTicket _bookTicketRepository;
        private readonly ILogger<BookTicketsController> _logger;


        public BookTicketsController(IBookTicket bookTicketRepository,
          ILogger<BookTicketsController> logger)
        {
            
            _bookTicketRepository = bookTicketRepository;
            _logger = logger;
        }

        // GET: api/BookTicket
        [HttpGet]
        public async Task<ActionResult<IEnumerable<BookTicket>>> GetBookTicket()
        {
            return await _bookTicketRepository.GetBookTicket();
        }
        [HttpGet("{userId}")]
        public async Task<ActionResult<IEnumerable<BookTicket>>> GetBookTicketsByUserId(long userId)

        {
            var bookTickets = await _bookTicketRepository.GetBookTicketsByUserId(userId);

            if (bookTickets == null)

            {

                return NotFound();

            }

            return bookTickets;

        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutBookTicket(int id, BookTicket bookTicket)
        {

            if (id != bookTicket.Bookid)
            {
                return BadRequest();
            }

            var ticket = await _bookTicketRepository.PutBookTicket(id, bookTicket);
            if (ticket == null)
                return NotFound();

            return Ok("Updated");
        }

        // POST: api/BookTickets

        [HttpPost]
        public async Task<ActionResult<BookTicket>> PostBookTicket(BookTicket bookTicket)
        { 
            await _bookTicketRepository.PostBookTicket(bookTicket);

            return CreatedAtAction("GetBookTicket", new { id = bookTicket.Bookid }, bookTicket);
        }

        // DELETE: api/BookTickets/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<BookTicket>> DeleteBookTicket(long id)
        {
         
            var bookTicket = await _bookTicketRepository.DeleteBookTicket(id);
            if (bookTicket == null)
            {
                return NotFound();
            }

            return bookTicket;
        }

        /*private bool BookTicketExists(long id)
        {
            return _context.BookTickets.Any(e => e.Bookid == id);
        }*/
    }
}
