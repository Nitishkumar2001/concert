﻿namespace ConcertBooking.Model
{
    public class Registrationdto
    {
        public string Token { get; set; }
    }
}
