﻿using Microsoft.EntityFrameworkCore;

namespace ConcertBooking.Model
{
    public class ConcertDbContext: DbContext
    {
        public ConcertDbContext(DbContextOptions<ConcertDbContext> options)
          : base(options)
        {

        }
        public DbSet<Registration> Registrations { get; set; }
        public DbSet<FindTicket> FindTickets { get; set; }
        public DbSet<BookTicket> BookTickets { get; set; }

       protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Registration>()
                  .Property(b => b.usertype)
                  .HasDefaultValue("Customer");
        }
    }
}
