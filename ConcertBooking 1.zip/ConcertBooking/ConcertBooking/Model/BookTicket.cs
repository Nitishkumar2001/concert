﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ConcertBooking.Model
{
    public class BookTicket
    {

        [Key]
        public long Bookid { get; set; }
        public int? Seatnum { get; set; }
        [ForeignKey("ConcertId")]
        public int? ConcertId { get; set; }
        [ForeignKey("UserId")]
        public int? UserId { get; set; }
        public DateTime? Date { get; set; }
        public virtual FindTicket Concert { get; set; }
        public virtual Registration User { get; set; }
    }
}
