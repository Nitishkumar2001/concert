﻿using System.ComponentModel.DataAnnotations;

namespace ConcertBooking.Model
{
    public class FindTicket
    {
        [Key]
        public int ConcertId { get; set; }
        public string Location { get; set; }
        public string Theatrename { get; set; }
        [Required(ErrorMessage = "Concert name is required")]
        public string Concertname { get; set; }

        public string Slot { get; set; }
        public int charges { get; set; }

        [Required(ErrorMessage = "Date is required")]
        public DateTime? date { get; set; }
        public string ConcertLink { get; set; }
    }
}
