﻿using ConcertBooking.Model;

using Microsoft.AspNetCore.Mvc;

namespace ConcertBooking.Repository
{
    public interface IRegistrationRepository
    {
        Task<ActionResult<IEnumerable<Registration>>> GetRegistration();
        Task<ActionResult<Registration>> GetRegistration(int id);
        Task<Registrationdto> GetRegistration(string email, string password);
        Task<ActionResult<Registration>> PostRegistration(Registration registration);
        Task<ActionResult<Registration>> PutRegistration(int id, Registration registration);
        Task<ActionResult<Registration>> DeleteRegistration(int id);
    }
}
