﻿using ConcertBooking.Controllers;
using ConcertBooking.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ConcertBooking.Repository
{
    public class FindTicketRepository:IFindTicket
    {
        private readonly ConcertDbContext _context;
        private readonly ILogger<FindTicketsController> _logger;
        private readonly IConfiguration configuration;
        public FindTicketRepository(ConcertDbContext context, ILogger<FindTicketsController> logger, IConfiguration configuration)
        {
            _context = context;
            _logger = logger;
            this.configuration = configuration;
        }
        public async Task<ActionResult<IEnumerable<FindTicket>>> GetFindTicket()
        {
            return await _context.FindTickets.ToListAsync();
        }

        public async Task<ActionResult<FindTicket>> GetFindTicket(int id)
        {
            var find = await _context.FindTickets.FindAsync(id);

            return find;
        }
        public async Task<ActionResult<FindTicket>> PostFindTicket(FindTicket findTicket)
        {
            _context.FindTickets.Add(findTicket);
            await _context.SaveChangesAsync();
            return findTicket;
        }

        public async Task<ActionResult<FindTicket>> PutFindTicket(int id, FindTicket findTicket)
        {
            _context.Entry(findTicket).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return findTicket;
        }

        public async Task<ActionResult<FindTicket>> DeleteFindTicket(int id)
        {
            var findTicket = await _context.FindTickets.FindAsync(id);
            _context.FindTickets.Remove(findTicket);
            await _context.SaveChangesAsync();
            return findTicket;
        }

        private bool FindTicketExists(int id)
       {
           return _context.FindTickets.Any(e => e.ConcertId == id);
       }
    }
}
